# WalkingParticles

<h3>An advanced and powerful particle trail plugin for your PocketMine server</h3>
